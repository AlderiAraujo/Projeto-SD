package com.projetosd.projetosd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoSdApplicationTests {

	@Test
	void contextLoads() {
	}

}
