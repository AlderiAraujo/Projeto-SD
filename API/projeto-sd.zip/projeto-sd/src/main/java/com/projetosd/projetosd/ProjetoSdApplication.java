package com.projetosd.projetosd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoSdApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoSdApplication.class, args);
	}

}
